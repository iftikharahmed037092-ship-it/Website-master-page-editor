const EditorState = {
  currentClient: null,
  activeTab: "store-info",
  activeProductId: null
};

const PreviewResizer = {
  STORAGE_KEY: "master_editor_preview_ratio",
  ratio: 0.56,
  dragging: false,
  raf: 0,
  pendingY: 0,

  init() {
    const splitter = document.getElementById("editorSplitter");
    const workspace = document.getElementById("workspace");
    const reset = document.getElementById("btnResetPreviewSize");
    if (!splitter || !workspace) return;

    const saved = Number(localStorage.getItem(this.STORAGE_KEY));
    if (Number.isFinite(saved) && saved >= 0.25 && saved <= 0.78) this.ratio = saved;

    this.apply();

    splitter.addEventListener("pointerdown", e => {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      this.dragging = true;
      this.pendingY = e.clientY;
      splitter.classList.add("dragging");
      document.body.classList.add("is-resizing");
      try { splitter.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
      this.schedule();
    });

    splitter.addEventListener("pointermove", e => {
      if (!this.dragging) return;
      this.pendingY = e.clientY;
      this.schedule();
      e.preventDefault();
    });

    const stop = e => {
      if (!this.dragging) return;
      this.dragging = false;
      splitter.classList.remove("dragging");
      document.body.classList.remove("is-resizing");
      try { splitter.releasePointerCapture(e.pointerId); } catch (_) {}
      this.save();
    };
    splitter.addEventListener("pointerup", stop);
    splitter.addEventListener("pointercancel", stop);
    splitter.addEventListener("lostpointercapture", () => {
      if (this.dragging) {
        this.dragging = false;
        splitter.classList.remove("dragging");
        document.body.classList.remove("is-resizing");
        this.save();
      }
    });

    splitter.addEventListener("keydown", e => {
      if (!["ArrowUp", "ArrowDown", "Home", "End"].includes(e.key)) return;
      e.preventDefault();
      if (e.key === "ArrowUp") this.ratio -= 0.03;
      if (e.key === "ArrowDown") this.ratio += 0.03;
      if (e.key === "Home") this.ratio = 0.25;
      if (e.key === "End") this.ratio = 0.78;
      this.clamp();
      this.apply();
      this.save();
    });

    if (reset) reset.addEventListener("click", () => this.reset());
    window.addEventListener("resize", () => this.apply());
  },

  schedule() {
    if (this.raf) return;
    this.raf = requestAnimationFrame(() => {
      this.raf = 0;
      const workspace = document.getElementById("workspace");
      if (!workspace || !this.dragging) return;
      const rect = workspace.getBoundingClientRect();
      if (!rect.height) return;
      this.ratio = (this.pendingY - rect.top) / rect.height;
      this.clamp();
      this.apply();
    });
  },

  clamp() {
    this.ratio = Math.max(0.25, Math.min(0.78, this.ratio));
  },

  apply() {
    const workspace = document.getElementById("workspace");
    if (!workspace) return;
    const height = workspace.getBoundingClientRect().height;
    if (!height) return;
    const splitterHeight = 12;
    const minEditor = 220;
    const minPreview = 260;
    const available = Math.max(0, height - splitterHeight);
    const minRatio = minPreview / available;
    const maxRatio = Math.min(0.78, 1 - minEditor / available);
    const safeRatio = Math.max(Math.min(this.ratio, maxRatio), Math.min(minRatio, maxRatio));
    this.ratio = safeRatio;
    const previewPx = Math.round(available * safeRatio);
    workspace.style.gridTemplateRows = `${previewPx}px ${splitterHeight}px minmax(220px, 1fr)`;
  },

  save() {
    try { localStorage.setItem(this.STORAGE_KEY, String(this.ratio)); } catch (_) {}
  },

  reset() {
    this.ratio = 0.56;
    this.apply();
    this.save();
    flashMessage("Preview size reset.");
  }
};

document.addEventListener("DOMContentLoaded", () => {
  try {
    bindTabButtons();
    bindGlobalActions();
    PreviewResizer.init();
    loadInitialClient();
  } catch (error) {
    console.error(error);
    alert("Editor could not start: " + error.message);
  }
});

/* ================= INITIALIZATION ================= */
function loadInitialClient() {
  const activeId = StorageManager.getActiveClientId();
  const existing = activeId ? StorageManager.loadClient(activeId) : null;
  EditorState.currentClient = existing || createEmptyClientData();
  if (!existing) EditorState.currentClient.meta.clientId = generateId("client");
  refreshClientDropdown();
  renderActiveTab();
  updatePreview();
}

/* ================= TABS ================= */
function bindTabButtons() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      EditorState.activeTab = btn.dataset.tab;
      EditorState.activeProductId = null;
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      renderActiveTab();
    });
  });
}

function renderActiveTab() {
  const container = document.getElementById("tabContent");
  if (!container) return;
  container.innerHTML = "";
  switch (EditorState.activeTab) {
    case "store-info": renderStoreInfoTab(container); break;
    case "branding": renderBrandingTab(container); break;
    case "products": renderProductsTab(container); break;
    case "policies": renderPoliciesTab(container); break;
    case "contact": renderContactTab(container); break;
    case "clients": renderClientsTab(container); break;
  }
}

/* ================= STORE INFO ================= */
function renderStoreInfoTab(container) {
  const s = EditorState.currentClient.store;
  container.innerHTML = `
    <h2>🏪 Store Information</h2>
    <label>Store Name *</label>
    <input type="text" id="fld-storeName" value="${escapeAttr(s.storeName)}" placeholder="For example, ABC Garments">
    <label>Tagline</label>
    <input type="text" id="fld-tagline" value="${escapeAttr(s.tagline)}" placeholder="Best price, best quality">
    <label>About Text</label>
    <textarea id="fld-aboutText" rows="6" placeholder="Introduce your store">${escapeHtml(s.aboutText)}</textarea>
    <div id="storeInfoErrors" class="error-box"></div>
    <div class="form-actions">
      <button class="btn btn-primary" id="btnSaveStoreInfo" type="button">💾 Save Store Information</button>
    </div>`;

  ["fld-storeName", "fld-tagline", "fld-aboutText"].forEach(id => {
    document.getElementById(id).addEventListener("input", () => {
      s.storeName = val("fld-storeName");
      s.tagline = val("fld-tagline");
      s.aboutText = val("fld-aboutText");
      updatePreview();
    });
  });

  document.getElementById("btnSaveStoreInfo").addEventListener("click", () => {
    s.storeName = val("fld-storeName");
    s.tagline = val("fld-tagline");
    s.aboutText = val("fld-aboutText");
    const result = Validation.validateStoreInfo(s, EditorState.currentClient.contact);
    showErrors("storeInfoErrors", result.errors);
    if (result.valid) {
      saveCurrentClient();
      flashMessage("Store information saved.");
    }
  });
}

/* ================= BRANDING ================= */
function renderBrandingTab(container) {
  const s = EditorState.currentClient.store;
  const banners = Array.isArray(s.bannerImages) ? s.bannerImages : [];
  container.innerHTML = `
    <h2>🎨 Branding &amp; Banners</h2>
    <label>Logo</label>
    <div class="image-row">
      ${s.logoUrl ? `<div class="thumb-wrap"><img class="thumb" src="${escapeAttr(s.logoUrl)}" alt="Logo"><button class="thumb-remove" id="btnRemoveLogo" type="button">✕</button></div>` : `<div class="thumb thumb-empty">No Logo</div>`}
      <input type="file" id="fld-logoUpload" accept="image/*">
    </div>
    <label>Primary Color</label>
    <input type="color" id="fld-primaryColor" value="${escapeAttr(s.primaryColor || "#16a34a")}">
    <label>Secondary Color</label>
    <input type="color" id="fld-secondaryColor" value="${escapeAttr(s.secondaryColor || "#0ea5e9")}">
    <label>Banner Images</label>
    <input type="file" id="fld-bannerUpload" accept="image/*" multiple>
    <div class="image-row" id="bannerThumbs">
      ${banners.length ? banners.map((b, i) => `<div class="thumb-wrap"><img class="thumb" src="${escapeAttr(b.url)}" alt="Banner ${i + 1}"><button class="thumb-remove" data-banner-remove="${i}" type="button">✕</button></div>`).join("") : `<em>No banners have been added yet.</em>`}
    </div>
    <div id="bannerErrors" class="error-box"></div>`;

  document.getElementById("fld-logoUpload").addEventListener("change", async e => {
    const file = e.target.files[0];
    if (!file) return;
    if (!isImageFile(file)) { showErrors("bannerErrors", ["Please select an image file."]); return; }
    s.logoUrl = await fileToDataURL(file);
    saveCurrentClient(); renderActiveTab(); updatePreview();
  });

  const removeLogo = document.getElementById("btnRemoveLogo");
  if (removeLogo) removeLogo.addEventListener("click", () => {
    s.logoUrl = ""; saveCurrentClient(); renderActiveTab(); updatePreview();
  });

  document.getElementById("fld-primaryColor").addEventListener("input", e => { s.primaryColor = e.target.value; updatePreview(); });
  document.getElementById("fld-secondaryColor").addEventListener("input", e => { s.secondaryColor = e.target.value; updatePreview(); });
  document.getElementById("fld-primaryColor").addEventListener("change", saveCurrentClient);
  document.getElementById("fld-secondaryColor").addEventListener("change", saveCurrentClient);

  document.getElementById("fld-bannerUpload").addEventListener("change", async e => {
    const files = Array.from(e.target.files || []);
    for (const file of files) {
      if (!isImageFile(file)) continue;
      banners.push({ url: await fileToDataURL(file), caption: "", link: "" });
    }
    s.bannerImages = banners;
    saveCurrentClient(); renderActiveTab(); updatePreview();
  });

  container.querySelectorAll("[data-banner-remove]").forEach(btn => {
    btn.addEventListener("click", () => {
      banners.splice(Number(btn.dataset.bannerRemove), 1);
      s.bannerImages = banners;
      saveCurrentClient(); renderActiveTab(); updatePreview();
    });
  });
}

/* ================= PRODUCTS ================= */
function renderProductsTab(container) {
  const client = EditorState.currentClient;
  if (EditorState.activeProductId) {
    renderProductEditor(container, EditorState.activeProductId);
    return;
  }

  container.innerHTML = `
    <h2>📦 Products</h2>
    <div class="form-actions">
      <button class="btn btn-primary" id="btnAddProduct" type="button">+ New Product</button>
      <button class="btn-secondary" id="btnAddCategory" type="button">+ New Category</button>
    </div>
    <div class="category-list">
      ${client.categories.length ? client.categories.map(c => `<span class="chip">${escapeHtml(c.name)} <button class="chip-x" data-cat="${escapeAttr(c.id)}" type="button">✕</button></span>`).join("") : `<em>No categories yet.</em>`}
    </div>
    <div style="overflow:auto">
      <table class="data-table">
        <thead><tr><th>Image</th><th>Name</th><th>Price</th><th>Variants</th><th>Stock</th><th>Actions</th></tr></thead>
        <tbody>
          ${client.products.length ? client.products.map(p => {
            const stock = p.variants.reduce((sum, v) => sum + Number(v.stock || 0), 0);
            return `<tr>
              <td>${p.images?.[0] ? `<img class="thumb-sm" src="${escapeAttr(p.images[0])}" alt="">` : "—"}</td>
              <td>${escapeHtml(p.name || "(Untitled)")}</td>
              <td>Rs. ${Number(p.price || 0).toLocaleString()}</td>
              <td>${p.variants.length}</td><td>${stock}</td>
              <td><button class="btn-small" data-edit="${escapeAttr(p.id)}" type="button">Edit</button> <button class="btn-small btn-danger" data-del="${escapeAttr(p.id)}" type="button">Delete</button></td>
            </tr>`;
          }).join("") : `<tr><td colspan="6"><em>No products yet.</em></td></tr>`}
        </tbody>
      </table>
    </div>`;

  document.getElementById("btnAddProduct").addEventListener("click", () => {
    const product = ProductManager.addProduct(client);
    EditorState.activeProductId = product.id;
    saveCurrentClient(); renderActiveTab();
  });

  document.getElementById("btnAddCategory").addEventListener("click", () => {
    const name = prompt("New Category name:");
    if (!name?.trim()) return;
    try {
      ProductManager.addCategory(client, name);
      saveCurrentClient(); renderActiveTab(); updatePreview();
    } catch (error) { alert(error.message); }
  });

  container.querySelectorAll("[data-edit]").forEach(btn => btn.addEventListener("click", () => {
    EditorState.activeProductId = btn.dataset.edit; renderActiveTab();
  }));

  container.querySelectorAll("[data-del]").forEach(btn => btn.addEventListener("click", () => {
    if (!confirm("Delete this product?")) return;
    ProductManager.deleteProduct(client, btn.dataset.del);
    saveCurrentClient(); renderActiveTab(); updatePreview();
  }));

  container.querySelectorAll("[data-cat]").forEach(btn => btn.addEventListener("click", () => {
    if (!confirm("Deleting this category will make its products Uncategorized. Continue?")) return;
    ProductManager.deleteCategory(client, btn.dataset.cat);
    saveCurrentClient(); renderActiveTab(); updatePreview();
  }));
}

/* ================= PRODUCT EDITOR ================= */
function renderProductEditor(container, productId) {
  const client = EditorState.currentClient;
  const product = ProductManager.getProduct(client, productId);
  if (!product) { EditorState.activeProductId = null; renderProductsTab(container); return; }

  container.innerHTML = `
    <button class="btn-link" id="btnBackToList" type="button">← Products List</button>
    <h2>📦 Edit Product</h2>
    <label>Product Name *</label>
    <input type="text" id="fld-pName" value="${escapeAttr(product.name)}">
    <label>Description</label>
    <textarea id="fld-pDesc" rows="5">${escapeHtml(product.description)}</textarea>
    <div class="two-col">
      <div><label>Price *</label><input type="number" id="fld-pPrice" value="${product.price}" min="0"></div>
      <div><label>Old Price</label><input type="number" id="fld-pOldPrice" value="${product.oldPrice}" min="0"></div>
    </div>
    <label>Category</label>
    <select id="fld-pCategory"><option value="">— Uncategorized —</option>${client.categories.map(c => `<option value="${escapeAttr(c.id)}" ${c.id === product.categoryId ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("")}</select>
    <label>Size Guide / Measurement Info</label>
    <textarea id="fld-pSizeGuide" rows="4">${escapeHtml(product.sizeGuide)}</textarea>
    <label>Product Images</label>
    <input type="file" id="fld-pImages" accept="image/*" multiple>
    <div class="image-row">
      ${product.images.length ? product.images.map((img, i) => `<div class="thumb-wrap"><img class="thumb" src="${escapeAttr(img)}" alt="Product image ${i + 1}"><button class="thumb-remove" data-imgidx="${i}" type="button">✕</button></div>`).join("") : `<em>No images yet.</em>`}
    </div>
    <h3>Size / Color Variants</h3>
    <div style="overflow:auto">
      <table class="data-table" id="variantTable">
        <thead><tr><th>Size</th><th>Color</th><th>Stock</th><th></th></tr></thead>
        <tbody>${product.variants.length ? product.variants.map(v => `<tr data-vid="${escapeAttr(v.id)}"><td><input type="text" class="v-size" value="${escapeAttr(v.size)}" placeholder="M, L, 40"></td><td><input type="text" class="v-color" value="${escapeAttr(v.color)}" placeholder="Black"></td><td><input type="number" class="v-stock" value="${v.stock}" min="0"></td><td><button class="btn-small btn-danger v-remove" type="button">✕</button></td></tr>`).join("") : `<tr><td colspan="4"><em>Variants are optional. Add one below if needed.</em></td></tr>`}</tbody>
      </table>
    </div>
    <button class="btn-secondary" id="btnAddVariant" type="button">+ Add Size / Color</button>
    <div id="productErrors" class="error-box"></div>
    <div class="form-actions"><button class="btn btn-primary" id="btnSaveProduct" type="button">💾 Save Product</button></div>`;

  document.getElementById("btnBackToList").addEventListener("click", () => { EditorState.activeProductId = null; renderActiveTab(); });

  document.getElementById("fld-pImages").addEventListener("change", async e => {
    const files = Array.from(e.target.files || []);
    for (const file of files) {
      if (!isImageFile(file)) continue;
      product.images.push(await fileToDataURL(file));
    }
    saveCurrentClient(); renderProductEditor(container, productId); updatePreview();
  });

  container.querySelectorAll("[data-imgidx]").forEach(btn => btn.addEventListener("click", () => {
    product.images.splice(Number(btn.dataset.imgidx), 1);
    saveCurrentClient(); renderProductEditor(container, productId); updatePreview();
  }));

  document.getElementById("btnAddVariant").addEventListener("click", () => {
    ProductManager.addVariant(client, productId);
    saveCurrentClient(); renderProductEditor(container, productId);
  });

  container.querySelectorAll(".v-remove").forEach(btn => btn.addEventListener("click", e => {
    const row = e.target.closest("tr");
    ProductManager.deleteVariant(client, productId, row.dataset.vid);
    saveCurrentClient(); renderProductEditor(container, productId);
  }));

  document.getElementById("btnSaveProduct").addEventListener("click", () => {
    product.name = val("fld-pName");
    product.description = val("fld-pDesc");
    product.price = Number(val("fld-pPrice")) || 0;
    product.oldPrice = Number(val("fld-pOldPrice")) || 0;
    product.categoryId = val("fld-pCategory");
    product.sizeGuide = val("fld-pSizeGuide");

    container.querySelectorAll("#variantTable tbody tr[data-vid]").forEach(row => {
      ProductManager.updateVariant(client, productId, row.dataset.vid, {
        size: row.querySelector(".v-size").value.trim(),
        color: row.querySelector(".v-color").value.trim(),
        stock: row.querySelector(".v-stock").value
      });
    });

    const result = Validation.validateProduct(product);
    showErrors("productErrors", result.errors);
    if (!result.valid) return;
    saveCurrentClient();
    EditorState.activeProductId = null;
    renderActiveTab(); updatePreview();
    flashMessage("Product saved.");
  });
}

/* ================= POLICIES ================= */
function renderPoliciesTab(container) {
  const p = EditorState.currentClient.policies;
  container.innerHTML = `
    <h2>📄 Policies</h2>
    <label>Shipping Policy</label><textarea id="fld-shipping" rows="5">${escapeHtml(p.shippingPolicy)}</textarea>
    <label>Return Policy</label><textarea id="fld-return" rows="5">${escapeHtml(p.returnPolicy)}</textarea>
    <label>Privacy Policy</label><textarea id="fld-privacy" rows="5">${escapeHtml(p.privacyPolicy)}</textarea>
    <label>Terms &amp; Conditions</label><textarea id="fld-terms" rows="5">${escapeHtml(p.termsAndConditions)}</textarea>
    <div class="form-actions"><button class="btn btn-primary" id="btnSavePolicies" type="button">💾 Save Policies</button></div>`;

  document.getElementById("btnSavePolicies").addEventListener("click", () => {
    p.shippingPolicy = val("fld-shipping"); p.returnPolicy = val("fld-return");
    p.privacyPolicy = val("fld-privacy"); p.termsAndConditions = val("fld-terms");
    saveCurrentClient(); updatePreview(); flashMessage("Policies saved.");
  });
}

/* ================= CONTACT ================= */
function renderContactTab(container) {
  const c = EditorState.currentClient.contact;
  container.innerHTML = `
    <h2>📞 Contact &amp; Social</h2>
    <label>WhatsApp Number * <small>Without +, for example 923001234567</small></label>
    <input type="text" id="fld-whatsapp" value="${escapeAttr(c.whatsappNumber)}">
    <label>Phone Number</label><input type="text" id="fld-phone" value="${escapeAttr(c.phoneNumber)}">
    <label>Address</label><input type="text" id="fld-address" value="${escapeAttr(c.address)}">
    <label>City</label><input type="text" id="fld-city" value="${escapeAttr(c.city)}">
    <label>Facebook URL</label><input type="url" id="fld-facebook" value="${escapeAttr(c.facebookUrl)}" placeholder="https://facebook.com/…">
    <label>Instagram URL</label><input type="url" id="fld-instagram" value="${escapeAttr(c.instagramUrl)}" placeholder="https://instagram.com/…">
    <div id="contactErrors" class="error-box"></div>
    <div class="form-actions"><button class="btn btn-primary" id="btnSaveContact" type="button">💾 Save Contact Information</button></div>`;

  document.getElementById("btnSaveContact").addEventListener("click", () => {
    c.whatsappNumber = val("fld-whatsapp").replace(/[^0-9]/g, "");
    c.phoneNumber = val("fld-phone"); c.address = val("fld-address"); c.city = val("fld-city");
    c.facebookUrl = val("fld-facebook"); c.instagramUrl = val("fld-instagram");
    const result = Validation.validateStoreInfo(EditorState.currentClient.store, c);
    showErrors("contactErrors", result.errors);
    if (!result.valid) return;
    saveCurrentClient(); updatePreview(); flashMessage("Contact information saved.");
  });
}

/* ================= CLIENTS ================= */
function renderClientsTab(container) {
  const ids = StorageManager.listClientIds();
  container.innerHTML = `
    <h2>👥 Clients Manager</h2>
    <p>Current Client ID: <strong>${escapeHtml(EditorState.currentClient.meta.clientId)}</strong></p>
    <div class="form-actions">
      <button class="btn btn-primary" id="btnNewClient" type="button">+ New Client</button>
      <button class="btn-secondary" id="btnExportJson" type="button">Export JSON</button>
      <label class="btn-secondary file-label">Import JSON<input type="file" id="fld-importJson" accept="application/json" hidden></label>
    </div>
    <div style="overflow:auto"><table class="data-table">
      <thead><tr><th>Client ID</th><th>Store Name</th><th>Actions</th></tr></thead>
      <tbody>${ids.length ? ids.map(id => {
        const c = StorageManager.loadClient(id);
        return `<tr><td>${escapeHtml(id)}</td><td>${escapeHtml(c?.store?.storeName || "(Untitled)")}</td><td><button class="btn-small" data-load="${escapeAttr(id)}" type="button">Load</button> <button class="btn-small btn-danger" data-remove="${escapeAttr(id)}" type="button">Delete</button></td></tr>`;
      }).join("") : `<tr><td colspan="3">No saved clients yet.</td></tr>`}</tbody>
    </table></div>`;

  document.getElementById("btnNewClient").addEventListener("click", () => {
    if (!confirm("Start a new Client?")) return;
    EditorState.currentClient = createEmptyClientData();
    EditorState.activeProductId = null;
    localStorage.removeItem(StorageManager.ACTIVE_CLIENT_KEY);
    refreshClientDropdown(); renderActiveTab(); updatePreview(); flashMessage("New client is ready.");
  });

  document.getElementById("btnExportJson").addEventListener("click", () => StorageManager.exportClientAsJSON(EditorState.currentClient));

  document.getElementById("fld-importJson").addEventListener("change", async e => {
    const file = e.target.files[0]; if (!file) return;
    try {
      const imported = await StorageManager.importClientFromJSONFile(file);
      const originalId = imported.meta.clientId;
      if (StorageManager.loadClient(originalId)) imported.meta.clientId = generateId("client");
      EditorState.currentClient = imported; EditorState.activeProductId = null;
      saveCurrentClient(); refreshClientDropdown(); renderActiveTab(); updatePreview();
      alert("Client data imported successfully.");
    } catch (error) { alert(error.message); }
    e.target.value = "";
  });

  container.querySelectorAll("[data-load]").forEach(btn => btn.addEventListener("click", () => {
    const loaded = StorageManager.loadClient(btn.dataset.load);
    if (!loaded) { alert("Client not found."); return; }
    EditorState.currentClient = loaded; EditorState.activeProductId = null;
    StorageManager.setActiveClient(loaded.meta.clientId);
    refreshClientDropdown(); renderActiveTab(); updatePreview(); flashMessage("Client loaded.");
  }));

  container.querySelectorAll("[data-remove]").forEach(btn => btn.addEventListener("click", () => {
    if (!confirm("Delete this Client completely?")) return;
    const deletingId = btn.dataset.remove;
    StorageManager.deleteClient(deletingId);
    if (EditorState.currentClient.meta.clientId === deletingId) {
      const remaining = StorageManager.listClientIds();
      if (remaining.length) {
        const next = StorageManager.loadClient(remaining[0]);
        EditorState.currentClient = next;
        StorageManager.setActiveClient(next.meta.clientId);
      } else {
        EditorState.currentClient = createEmptyClientData();
        localStorage.removeItem(StorageManager.ACTIVE_CLIENT_KEY);
      }
      EditorState.activeProductId = null;
    }
    refreshClientDropdown(); renderActiveTab(); updatePreview(); flashMessage("Client deleted.");
  }));
}

/* ================= GLOBAL ACTIONS ================= */
function bindGlobalActions() {
  document.getElementById("btnGlobalSave").addEventListener("click", () => {
    try { saveCurrentClient(); refreshClientDropdown(); flashMessage("Client saved."); }
    catch (error) { alert(error.message); }
  });

  document.getElementById("btnGlobalGenerate").addEventListener("click", () => {
    alert("Client Website Generator will be added in Part 3. The Master Editor can currently prepare and save Client data.");
  });
}

/* ================= HELPERS ================= */
function saveCurrentClient() {
  EditorState.currentClient = normalizeClientData(EditorState.currentClient);
  StorageManager.saveClient(EditorState.currentClient);
}

function refreshClientDropdown() {
  const select = document.getElementById("quickClientSelect");
  if (!select) return;
  const ids = StorageManager.listClientIds();
  const currentId = EditorState.currentClient?.meta?.clientId || "";
  select.innerHTML = `<option value="">— Select Client —</option>` + ids.map(id => {
    const c = StorageManager.loadClient(id);
    return `<option value="${escapeAttr(id)}" ${id === currentId ? "selected" : ""}>${escapeHtml(c?.store?.storeName || id)}</option>`;
  }).join("");
  select.onchange = () => {
    if (!select.value) return;
    const loaded = StorageManager.loadClient(select.value);
    if (!loaded) return;
    EditorState.currentClient = loaded; EditorState.activeProductId = null;
    StorageManager.setActiveClient(loaded.meta.clientId);
    renderActiveTab(); updatePreview();
  };
}

function updatePreview() { LivePreview.render(EditorState.currentClient); }
function val(id) { const el = document.getElementById(id); return el ? el.value.trim() : ""; }
function escapeHtml(value) {
  if (value === null || value === undefined) return "";
  return String(value).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
function escapeAttr(value) { return escapeHtml(value); }
function showErrors(containerId, errors) {
  const box = document.getElementById(containerId);
  if (!box) return;
  box.innerHTML = errors.length ? `<ul>${errors.map(e => `<li>${escapeHtml(e)}</li>`).join("")}</ul>` : "";
}
function flashMessage(message) {
  const el = document.getElementById("flashMessage");
  if (!el) return;
  el.textContent = message; el.classList.add("show");
  clearTimeout(flashMessage.timer);
  flashMessage.timer = setTimeout(() => el.classList.remove("show"), 2200);
}
function fileToDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("The image could not be read."));
    reader.readAsDataURL(file);
  });
}
function isImageFile(file) { return Boolean(file && typeof file.type === "string" && file.type.startsWith("image/")); }
