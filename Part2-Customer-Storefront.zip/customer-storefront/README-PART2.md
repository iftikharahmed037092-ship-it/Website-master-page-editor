# Part 2 — Customer Storefront

## اس حصے میں کیا بنا

یہ اصل **Customer-facing Online Shopping Website** ہے — یہی وہ website ہے جو آخر میں کسی client کے customers دیکھیں گے۔

```
customer-storefront/
├── index.html            ← Homepage (Banner, Categories, Featured Products)
├── shop.html              ← تمام Products + Search + Category Filter
├── product.html            ← Product Detail (Gallery, Size/Color, Add to Cart)
├── cart.html               ← Cart (منتخب کردہ Size/Color/Quantity)
├── checkout.html           ← Checkout (COD + WhatsApp Order)
├── contact.html            ← About + Contact + Social Links
├── policies.html           ← Shipping/Return/Privacy/Terms (Tabs)
├── css/
│   ├── storefront.css      ← مرکزی ڈیزائن (رنگ client کے مطابق خودکار بدلتے ہیں)
│   └── responsive.css      ← مکمل Mobile Responsiveness
├── js/
│   ├── cart-manager.js     ← Cart کی منطق (localStorage)
│   ├── storefront-common.js← Header/Footer, Theming, WhatsApp message builder
│   ├── home-page.js        ← صرف index.html
│   ├── shop-page.js        ← صرف shop.html
│   ├── product-page.js     ← صرف product.html (Variant selection کی مکمل منطق)
│   ├── cart-page.js        ← صرف cart.html
│   └── checkout.js         ← صرف checkout.html
└── data/
    └── client-data.js      ← ⚠️ نمونہ/Demo data — Part 3 Generator اسے ہر client کے
                                اصل data سے تبدیل کرے گا
```

**کل فائلیں: 15** (پلان میں 10–12 بتائی گئی تھیں؛ modularity برقرار رکھنے کے لیے
ہر page کی JS الگ فائل میں رکھی گئی، کیونکہ ہر page کی منطق دوسرے سے آزاد ہے)۔

## اہم Design Decision

Storefront میں کہیں بھی کسی client کی معلومات **hard-code نہیں** کی گئیں۔
ہر صفحہ صرف ایک ہی جگہ سے ڈیٹا پڑھتا ہے: `window.CLIENT_DATA` (جو
`data/client-data.js` میں define ہے)۔ یہ بالکل وہی schema ہے جو Part 1 کے
Private Editor میں استعمال ہوا۔

اس کا مطلب: Part 3 میں Website Generator کو صرف اتنا کرنا ہوگا کہ Editor میں
موجود اصل client کا data لے کر `data/client-data.js` بنائے اور باقی تمام
(HTML/CSS/JS) files جوں کی توں copy کر دے۔ Master Template پر دوبارہ کوچنگ کی
ضرورت نہیں پڑے گی۔

## اہم Functional تفصیلات

- **Variant Selection**: Size اور Color الگ الگ منتخب ہوتے ہیں، لیکن ناقابلِ دستیاب
  combinations خودکار طور پر disabled ہو جاتے ہیں (stock کی بنیاد پر)۔
- **Cart**: ایک ہی پروڈکٹ کے مختلف Size/Color ہمیشہ الگ cart lines کے طور پر رکھے
  جاتے ہیں (`lineId = productId__size__color`)، تاکہ غلط سائز جانے کا امکان نہ رہے۔
- **WhatsApp Order**: `encodeURIComponent` استعمال کیا گیا ہے تاکہ Urdu/English
  ملے جلے text، spaces اور خاص حروف کی وجہ سے message خراب نہ ہو۔
- **Checkout**: Cash on Delivery بنیادی طریقہ ہے؛ Confirm کرنے پر WhatsApp پر
  مکمل آرڈر تفصیل کے ساتھ پیغام چلا جاتا ہے اور کارٹ خالی ہو جاتا ہے۔
- **Responsive**: `responsive.css` میں 900px, 640px, اور 380px کے breakpoints
  شامل ہیں؛ موبائل پر header کا مینیو hamburger میں بدل جاتا ہے۔

## کیسے ٹیسٹ کریں

`customer-storefront/index.html` کو براہ راست browser میں کھولیں۔ ابھی
`data/client-data.js` میں "Zeenat Garments" کے نام سے نمونہ data موجود ہے —
اسی سے پوری websites (Home → Shop → Product → Cart → Checkout) کو end-to-end
ٹیسٹ کیا جا سکتا ہے۔

## اگلے Parts کے ساتھ Connection

- **Part 3 (Website Generator)**: Private Editor کے موجودہ client data کو
  اسی schema میں `data/client-data.js` کی صورت میں لکھے گا، پوری
  `customer-storefront/` folder کو client کی images کے ساتھ ملا کر ایک
  ZIP (مثلاً `ABC-Garments.zip`) بنائے گا۔
- **Part 4 (Final Integration)**: Editor کے "Generate Client Website" بٹن کو
  اصل Generator سے جوڑے گا اور مکمل flow کو test/validate کرے گا۔

## اگلا قدم

اب میں **Part 3 — Website Generator** بنانا شروع کر سکتا ہوں: Client data کو
Storefront Template کے ساتھ combine کرنا، images کو inject کرنا، اور مکمل ZIP
بنانا/download کروانا۔ بتائیں کہ آگے بڑھوں؟
