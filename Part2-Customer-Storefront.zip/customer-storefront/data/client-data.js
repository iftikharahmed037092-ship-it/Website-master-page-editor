/**
 * client-data.js
 * Part 2 — Customer Storefront (Sample/Demo Data)
 *
 * ⚠️ اہم: یہ فائل Part 3 کا "Website Generator" ہر client کے لیے خودکار طور پر
 * بدل دے گا (اسی schema میں، جو Part 1 کے store-data.js میں بیان کیا گیا ہے)۔
 * ابھی یہاں ایک نمونہ (Demo Garments Store) موجود ہے تاکہ Storefront کو
 * مکمل طور پر test کیا جا سکے۔
 *
 * Storefront کی تمام pages صرف window.CLIENT_DATA پڑھتی ہیں —
 * کہیں بھی hard-coded client معلومات موجود نہیں۔
 */

window.CLIENT_DATA = {
  meta: {
    clientId: "demo-garments",
    generatedAt: "",
    schemaVersion: "1.0"
  },

  store: {
    storeName: "Zeenat Garments",
    logoUrl: "",
    faviconUrl: "",
    primaryColor: "#1a2e35",
    secondaryColor: "#c98a4b",
    bannerImages: [
      { url: "", caption: "نئے Winter Collection پر خصوصی رعایت", link: "" }
    ],
    aboutText: "Zeenat Garments ایک مقامی برانڈ ہے جو معیاری کپڑے مناسب قیمت پر پیش کرتا ہے۔ ہم کوالٹی اور کسٹمر کے اعتماد کو اولین ترجیح دیتے ہیں۔",
    tagline: "معیار جو نظر بھی آئے اور محسوس بھی ہو"
  },

  contact: {
    whatsappNumber: "923001234567",
    phoneNumber: "0300-1234567",
    address: "Main Boulevard, Gulberg",
    city: "Lahore",
    facebookUrl: "https://facebook.com/",
    instagramUrl: "https://instagram.com/"
  },

  policies: {
    shippingPolicy: "پورے پاکستان میں 3-5 کاروباری دنوں کے اندر ڈیلیوری کی جاتی ہے۔ ڈیلیوری چارجز شہر کے مطابق مختلف ہو سکتے ہیں۔",
    returnPolicy: "پروڈکٹ کی وصولی کے 3 دن کے اندر، اگر پروڈکٹ میں کوئی خرابی ہو تو واپسی یا تبدیلی کی جا سکتی ہے۔ استعمال شدہ یا دھلی ہوئی اشیاء واپس نہیں ہوں گی۔",
    privacyPolicy: "آپ کی معلومات صرف آرڈر مکمل کرنے کے لیے استعمال ہوں گی اور کسی تیسرے فریق کے ساتھ شیئر نہیں کی جائیں گی۔",
    termsAndConditions: "ویب سائٹ استعمال کرتے ہوئے آپ ہماری تمام شرائط سے متفق تصور ہوں گے۔ قیمتوں میں تبدیلی کا حق محفوظ ہے۔"
  },

  categories: [
    { id: "cat_shirts", name: "Shirts" },
    { id: "cat_kurta", name: "Kurta" }
  ],

  products: [
    {
      id: "prod_001",
      name: "Classic Cotton Shirt",
      description: "پریمیم کاٹن سے تیار کردہ کلاسک شرٹ، روزمرہ اور دفتری استعمال کے لیے بہترین۔",
      price: 2499,
      oldPrice: 2999,
      categoryId: "cat_shirts",
      images: [],
      sizeGuide: "Size Chart: S (چھاتی 38\"), M (چھاتی 40\"), L (چھاتی 42\"), XL (چھاتی 44\")",
      variants: [
        { id: "v1", size: "M", color: "Sky Blue", stock: 8 },
        { id: "v2", size: "L", color: "Sky Blue", stock: 5 },
        { id: "v3", size: "M", color: "White", stock: 0 },
        { id: "v4", size: "L", color: "White", stock: 4 },
        { id: "v5", size: "XL", color: "White", stock: 3 }
      ]
    },
    {
      id: "prod_002",
      name: "Embroidered Kurta",
      description: "ہاتھ سے کڑھائی شدہ خوبصورت کرتا، خاص مواقع کے لیے موزوں۔",
      price: 3799,
      oldPrice: 0,
      categoryId: "cat_kurta",
      images: [],
      sizeGuide: "Size Chart: M, L, XL دستیاب ہیں۔",
      variants: [
        { id: "v6", size: "M", color: "Maroon", stock: 6 },
        { id: "v7", size: "L", color: "Maroon", stock: 6 },
        { id: "v8", size: "L", color: "Black", stock: 2 }
      ]
    }
  ]
};
