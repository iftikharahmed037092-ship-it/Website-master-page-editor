/**
 * storefront-common.js
 * Part 2 — Customer Storefront
 *
 * ہر page میں شامل ہونے والا مشترکہ منطق:
 * - CLIENT_DATA کے رنگوں کو پورے site پر لاگو کرنا (CSS variables)
 * - Header اور Footer کو خودکار طور پر render کرنا (تاکہ ہر HTML page میں دہرانا نہ پڑے)
 * - Product Card بنانا (Shop اور Home دونوں استعمال کرتے ہیں)
 * - WhatsApp کے لیے صحیح URL-encoded message بنانا
 * - قیمت فارمیٹنگ
 */

const StoreCommon = (function () {

  function init() {
    applyTheme();
    renderHeader();
    renderFooter();
    CartManager.updateCartBadge();
  }

  function applyTheme() {
    const s = window.CLIENT_DATA.store;
    document.documentElement.style.setProperty("--brand-primary", s.primaryColor || "#1a1a1a");
    document.documentElement.style.setProperty("--brand-secondary", s.secondaryColor || "#c98a4b");
    document.title = document.title
      ? `${document.title} | ${s.storeName}`
      : s.storeName;

    const favicon = document.querySelector("link[rel='icon']");
    if (favicon && s.faviconUrl) favicon.href = s.faviconUrl;
  }

  function renderHeader() {
    const holder = document.getElementById("siteHeader");
    if (!holder) return;
    const s = window.CLIENT_DATA.store;

    holder.innerHTML = `
      <div class="announce-bar">${escapeHtml(s.tagline || "")}</div>
      <header class="site-header">
        <a href="index.html" class="brand">
          ${s.logoUrl ? `<img src="${s.logoUrl}" alt="${escapeHtml(s.storeName)}">` : ""}
          <span>${escapeHtml(s.storeName)}</span>
        </a>

        <nav class="main-nav" id="mainNav">
          <a href="index.html">ہوم</a>
          <a href="shop.html">شاپ</a>
          <a href="contact.html">رابطہ</a>
          <a href="policies.html">پالیسیز</a>
        </nav>

        <div class="header-actions">
          <button class="icon-btn" id="mobileMenuToggle" aria-label="مینیو">☰</button>
          <a href="cart.html" class="icon-btn cart-link">
            🛒 <span class="cart-count-badge">0</span>
          </a>
        </div>
      </header>
    `;

    const toggle = document.getElementById("mobileMenuToggle");
    const nav = document.getElementById("mainNav");
    if (toggle && nav) {
      toggle.addEventListener("click", () => nav.classList.toggle("open"));
    }
  }

  function renderFooter() {
    const holder = document.getElementById("siteFooter");
    if (!holder) return;
    const s = window.CLIENT_DATA.store;
    const c = window.CLIENT_DATA.contact;

    holder.innerHTML = `
      <footer class="site-footer">
        <div class="footer-grid">
          <div>
            <h4>${escapeHtml(s.storeName)}</h4>
            <p>${escapeHtml(s.aboutText || "")}</p>
          </div>
          <div>
            <h4>روابط</h4>
            <a href="index.html">ہوم</a>
            <a href="shop.html">شاپ</a>
            <a href="contact.html">رابطہ</a>
          </div>
          <div>
            <h4>پالیسیز</h4>
            <a href="policies.html#shipping">شپنگ پالیسی</a>
            <a href="policies.html#return">ریٹرن پالیسی</a>
            <a href="policies.html#privacy">پرائیویسی پالیسی</a>
            <a href="policies.html#terms">شرائط و ضوابط</a>
          </div>
          <div>
            <h4>رابطہ کریں</h4>
            <p>${escapeHtml(c.address || "")}${c.city ? ", " + escapeHtml(c.city) : ""}</p>
            <p>${escapeHtml(c.phoneNumber || "")}</p>
            <div class="footer-social">
              ${c.facebookUrl ? `<a href="${c.facebookUrl}" target="_blank" rel="noopener">Facebook</a>` : ""}
              ${c.instagramUrl ? `<a href="${c.instagramUrl}" target="_blank" rel="noopener">Instagram</a>` : ""}
            </div>
          </div>
        </div>
        <div class="footer-bottom">© ${new Date().getFullYear()} ${escapeHtml(s.storeName)}. تمام حقوق محفوظ ہیں۔</div>
      </footer>
    `;
  }

  /** Product Card HTML — Home اور Shop page دونوں میں استعمال ہوتا ہے */
  function productCard(p) {
    const totalStock = p.variants.reduce((sum, v) => sum + Number(v.stock || 0), 0);
    const hasDiscount = p.oldPrice && Number(p.oldPrice) > Number(p.price);
    const img = p.images && p.images[0] ? p.images[0] : "";

    return `
      <a class="product-card" href="product.html?id=${encodeURIComponent(p.id)}">
        <div class="product-card-img">
          ${img ? `<img src="${img}" alt="${escapeHtml(p.name)}">` : `<div class="img-placeholder">No Image</div>`}
          ${hasDiscount ? `<span class="badge-discount">Sale</span>` : ""}
          ${totalStock === 0 ? `<span class="badge-outofstock">Out of Stock</span>` : ""}
        </div>
        <div class="product-card-body">
          <p class="product-card-name">${escapeHtml(p.name)}</p>
          <div class="product-card-price">
            <span class="price-now">${formatPrice(p.price)}</span>
            ${hasDiscount ? `<span class="price-old">${formatPrice(p.oldPrice)}</span>` : ""}
          </div>
        </div>
      </a>
    `;
  }

  function formatPrice(value) {
    const num = Number(value) || 0;
    return "Rs. " + num.toLocaleString("en-PK");
  }

  /**
   * WhatsApp order link بناتا ہے۔ encodeURIComponent استعمال کیا گیا ہے تاکہ
   * Urdu/English text، spaces اور خاص حروف کی وجہ سے message خراب نہ ہو۔
   */
  function buildWhatsAppLink(number, message) {
    return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
  }

  function buildOrderMessage({ storeName, items, customer }) {
    const lines = [];
    lines.push(`نیا آرڈر — ${storeName}`);
    lines.push("");
    items.forEach((i, idx) => {
      lines.push(`${idx + 1}) ${i.productName}`);
      lines.push(`   Size: ${i.size} | Color: ${i.color} | Qty: ${i.quantity}`);
      lines.push(`   Price: ${formatPrice(i.price)} x ${i.quantity} = ${formatPrice(i.price * i.quantity)}`);
    });
    lines.push("");
    lines.push(`Total: ${formatPrice(items.reduce((s, i) => s + i.price * i.quantity, 0))}`);
    lines.push("");
    lines.push(`نام: ${customer.name}`);
    lines.push(`فون: ${customer.phone}`);
    lines.push(`پتہ: ${customer.address}, ${customer.city}`);
    if (customer.notes) lines.push(`نوٹس: ${customer.notes}`);
    return lines.join("\n");
  }

  function escapeHtml(str) {
    if (!str) return "";
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function getQueryParam(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  return { init, productCard, formatPrice, buildWhatsAppLink, buildOrderMessage, escapeHtml, getQueryParam };
})();

window.StoreCommon = StoreCommon;
document.addEventListener("DOMContentLoaded", () => StoreCommon.init());
