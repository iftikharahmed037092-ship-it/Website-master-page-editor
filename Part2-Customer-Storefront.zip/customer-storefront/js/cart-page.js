/**
 * cart-page.js
 * Part 2 — Customer Storefront
 *
 * صرف cart.html پر چلتا ہے۔ Cart میں موجود ہر item (اپنی مخصوص Size/Color کے ساتھ)
 * الگ line کے طور پر دکھاتا ہے، quantity بدلنے اور item ہٹانے کی سہولت دیتا ہے۔
 */

document.addEventListener("DOMContentLoaded", renderCartPage);

function renderCartPage() {
  const container = document.getElementById("cartContainer");
  const items = CartManager.getCart();

  if (items.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>آپ کا کارٹ خالی ہے۔</p>
        <a href="shop.html" class="btn-primary">شاپنگ شروع کریں</a>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <table class="cart-table">
      <thead>
        <tr><th></th><th>پروڈکٹ</th><th>Size</th><th>Color</th><th>قیمت</th><th>مقدار</th><th>ٹوٹل</th><th></th></tr>
      </thead>
      <tbody>
        ${items.map(i => `
          <tr data-line="${i.lineId}">
            <td>${i.image ? `<img class="cart-thumb" src="${i.image}">` : `<div class="cart-thumb img-placeholder"></div>`}</td>
            <td>${StoreCommon.escapeHtml(i.productName)}</td>
            <td>${StoreCommon.escapeHtml(i.size)}</td>
            <td>${StoreCommon.escapeHtml(i.color)}</td>
            <td>${StoreCommon.formatPrice(i.price)}</td>
            <td>
              <div class="qty-control small">
                <button class="cart-qty-minus">−</button>
                <input type="number" class="cart-qty-input" value="${i.quantity}" min="1" max="${i.maxStock}">
                <button class="cart-qty-plus">+</button>
              </div>
            </td>
            <td class="line-total">${StoreCommon.formatPrice(i.price * i.quantity)}</td>
            <td><button class="btn-small btn-danger cart-remove">✕</button></td>
          </tr>
        `).join("")}
      </tbody>
    </table>

    <div class="cart-summary">
      <div class="cart-total">کل رقم: <strong>${StoreCommon.formatPrice(CartManager.getTotal())}</strong></div>
      <a href="checkout.html" class="btn-primary btn-large">Checkout پر جائیں</a>
    </div>
  `;

  bindCartEvents();
}

function bindCartEvents() {
  document.querySelectorAll(".cart-qty-minus").forEach(btn => {
    btn.addEventListener("click", () => {
      const row = btn.closest("tr");
      const input = row.querySelector(".cart-qty-input");
      changeQty(row.dataset.line, Number(input.value) - 1);
    });
  });

  document.querySelectorAll(".cart-qty-plus").forEach(btn => {
    btn.addEventListener("click", () => {
      const row = btn.closest("tr");
      const input = row.querySelector(".cart-qty-input");
      changeQty(row.dataset.line, Number(input.value) + 1);
    });
  });

  document.querySelectorAll(".cart-qty-input").forEach(input => {
    input.addEventListener("change", () => {
      const row = input.closest("tr");
      changeQty(row.dataset.line, Number(input.value));
    });
  });

  document.querySelectorAll(".cart-remove").forEach(btn => {
    btn.addEventListener("click", () => {
      const row = btn.closest("tr");
      CartManager.removeItem(row.dataset.line);
      renderCartPage();
    });
  });
}

function changeQty(lineId, qty) {
  CartManager.updateQuantity(lineId, qty);
  renderCartPage();
}
