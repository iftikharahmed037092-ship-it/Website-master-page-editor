/**
 * cart-manager.js
 * Part 2 — Customer Storefront
 *
 * ذمہ داری: Cart کو localStorage میں محفوظ رکھنا۔
 * ایک ہی پروڈکٹ کے مختلف Size/Color کو ہمیشہ الگ cart item کے طور پر رکھا جاتا ہے
 * تاکہ غلط سائز جانے کا امکان ختم ہو۔
 */

const CartManager = (function () {
  const clientId = (window.CLIENT_DATA && window.CLIENT_DATA.meta.clientId) || "store";
  const CART_KEY = `cart_${clientId}`;

  function getCart() {
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : [];
  }

  function saveCart(items) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    updateCartBadge();
  }

  /**
   * پروڈکٹ کو مخصوص Size/Color کے ساتھ cart میں شامل کرتا ہے۔
   * اگر بالکل وہی product+size+color پہلے سے موجود ہو تو صرف quantity بڑھے گی۔
   */
  function addToCart({ productId, productName, image, size, color, price, quantity, maxStock }) {
    const items = getCart();
    const lineId = buildLineId(productId, size, color);
    const existing = items.find(i => i.lineId === lineId);

    if (existing) {
      existing.quantity = Math.min(existing.quantity + quantity, maxStock);
    } else {
      items.push({
        lineId,
        productId,
        productName,
        image,
        size,
        color,
        price,
        quantity: Math.min(quantity, maxStock),
        maxStock
      });
    }
    saveCart(items);
    return items;
  }

  function buildLineId(productId, size, color) {
    return `${productId}__${size}__${color}`;
  }

  function updateQuantity(lineId, quantity) {
    const items = getCart();
    const item = items.find(i => i.lineId === lineId);
    if (!item) return items;
    item.quantity = Math.max(1, Math.min(quantity, item.maxStock));
    saveCart(items);
    return items;
  }

  function removeItem(lineId) {
    const items = getCart().filter(i => i.lineId !== lineId);
    saveCart(items);
    return items;
  }

  function clearCart() {
    saveCart([]);
  }

  function getTotal() {
    return getCart().reduce((sum, i) => sum + i.price * i.quantity, 0);
  }

  function getCount() {
    return getCart().reduce((sum, i) => sum + i.quantity, 0);
  }

  function updateCartBadge() {
    document.querySelectorAll(".cart-count-badge").forEach(el => {
      el.textContent = getCount();
    });
  }

  return { getCart, addToCart, updateQuantity, removeItem, clearCart, getTotal, getCount, updateCartBadge, buildLineId };
})();

window.CartManager = CartManager;
document.addEventListener("DOMContentLoaded", () => CartManager.updateCartBadge());
