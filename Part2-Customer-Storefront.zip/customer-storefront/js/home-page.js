/**
 * home-page.js
 * Part 2 — Customer Storefront
 *
 * صرف index.html پر چلتا ہے: Banner Slider، Featured Categories، Featured Products۔
 */

document.addEventListener("DOMContentLoaded", () => {
  renderBanner();
  renderFeaturedCategories();
  renderFeaturedProducts();
});

function renderBanner() {
  const holder = document.getElementById("bannerSlider");
  const banners = window.CLIENT_DATA.store.bannerImages;
  const s = window.CLIENT_DATA.store;

  if (!banners || banners.length === 0) {
    holder.innerHTML = `
      <div class="banner-slide banner-fallback">
        <h1>${StoreCommon.escapeHtml(s.storeName)}</h1>
        <p>${StoreCommon.escapeHtml(s.tagline || "")}</p>
        <a href="shop.html" class="btn-primary btn-large">ابھی خریداری کریں</a>
      </div>
    `;
    return;
  }

  let current = 0;
  function paint() {
    const b = banners[current];
    holder.innerHTML = `
      <div class="banner-slide" style="background-image:url('${b.url}')">
        <div class="banner-overlay">
          <h1>${StoreCommon.escapeHtml(b.caption || s.tagline || s.storeName)}</h1>
          <a href="shop.html" class="btn-primary btn-large">ابھی خریداری کریں</a>
        </div>
      </div>
      ${banners.length > 1 ? `
        <div class="banner-dots">
          ${banners.map((_, i) => `<span class="dot ${i === current ? "active" : ""}" data-idx="${i}"></span>`).join("")}
        </div>
      ` : ""}
    `;
    if (banners.length > 1) {
      holder.querySelectorAll(".dot").forEach(dot => {
        dot.addEventListener("click", () => { current = Number(dot.dataset.idx); paint(); });
      });
    }
  }
  paint();

  if (banners.length > 1) {
    setInterval(() => {
      current = (current + 1) % banners.length;
      paint();
    }, 5000);
  }
}

function renderFeaturedCategories() {
  const holder = document.getElementById("featuredCategories");
  const categories = window.CLIENT_DATA.categories;
  if (!categories.length) { holder.style.display = "none"; return; }

  holder.innerHTML = categories.map(c => `
    <a class="category-card" href="shop.html?category=${encodeURIComponent(c.id)}">
      <span>${StoreCommon.escapeHtml(c.name)}</span>
    </a>
  `).join("");
}

function renderFeaturedProducts() {
  const holder = document.getElementById("featuredProducts");
  const products = window.CLIENT_DATA.products.slice(0, 8);

  holder.innerHTML = products.length
    ? products.map(p => StoreCommon.productCard(p)).join("")
    : `<p class="empty-state">ابھی کوئی پروڈکٹ شامل نہیں کیا گیا۔</p>`;
}
