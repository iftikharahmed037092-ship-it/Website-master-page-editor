/**
 * shop-page.js
 * Part 2 — Customer Storefront
 *
 * صرف shop.html پر چلتا ہے۔ تمام products دکھاتا ہے، Search اور Category Filter
 * کے ساتھ۔
 */

document.addEventListener("DOMContentLoaded", () => {
  renderCategoryFilters();
  renderProducts();

  document.getElementById("searchInput").addEventListener("input", renderProducts);
  document.getElementById("sortSelect").addEventListener("change", renderProducts);
});

function renderCategoryFilters() {
  const holder = document.getElementById("categoryFilters");
  const categories = window.CLIENT_DATA.categories;

  holder.innerHTML = `
    <button class="filter-chip active" data-cat="">تمام</button>
    ${categories.map(c => `<button class="filter-chip" data-cat="${c.id}">${StoreCommon.escapeHtml(c.name)}</button>`).join("")}
  `;

  holder.querySelectorAll(".filter-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      holder.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      renderProducts();
    });
  });
}

function renderProducts() {
  const holder = document.getElementById("productGrid");
  const searchTerm = (document.getElementById("searchInput").value || "").trim().toLowerCase();
  const sortBy = document.getElementById("sortSelect").value;
  const activeChip = document.querySelector(".filter-chip.active");
  const activeCat = activeChip ? activeChip.dataset.cat : "";

  let products = window.CLIENT_DATA.products.filter(p => {
    const matchesSearch = !searchTerm || p.name.toLowerCase().includes(searchTerm);
    const matchesCategory = !activeCat || p.categoryId === activeCat;
    return matchesSearch && matchesCategory;
  });

  if (sortBy === "price-low") products = products.slice().sort((a, b) => a.price - b.price);
  if (sortBy === "price-high") products = products.slice().sort((a, b) => b.price - a.price);

  holder.innerHTML = products.length
    ? products.map(p => StoreCommon.productCard(p)).join("")
    : `<p class="empty-state">کوئی پروڈکٹ نہیں ملا۔</p>`;
}
