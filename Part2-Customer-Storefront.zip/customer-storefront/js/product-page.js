/**
 * product-page.js
 * Part 2 — Customer Storefront
 *
 * صرف product.html پر چلتا ہے۔ ذمہ داری:
 * - URL سے ?id=... پڑھ کر صحیح پروڈکٹ دکھانا
 * - Size اور Color کو الگ الگ منتخب کروانا، لیکن صرف وہ combinations selectable
 *   ہوں جن میں stock دستیاب ہو (unavailable ہمیشہ disabled رہیں)
 * - منتخب کردہ exact variant کے مطابق Add to Cart / Buy Now
 */

(function () {
  let product = null;
  let selectedSize = null;
  let selectedColor = null;
  let selectedImageIndex = 0;

  document.addEventListener("DOMContentLoaded", () => {
    const id = StoreCommon.getQueryParam("id");
    product = window.CLIENT_DATA.products.find(p => p.id === id);

    const container = document.getElementById("productDetail");
    if (!product) {
      container.innerHTML = `<p class="empty-state">یہ پروڈکٹ نہیں ملا۔ <a href="shop.html">شاپ پر واپس جائیں</a></p>`;
      return;
    }

    render();
  });

  function render() {
    const container = document.getElementById("productDetail");
    const hasDiscount = product.oldPrice && Number(product.oldPrice) > Number(product.price);
    const sizes = [...new Set(product.variants.map(v => v.size))];
    const colors = [...new Set(product.variants.map(v => v.color))];
    const images = product.images.length ? product.images : [""];

    container.innerHTML = `
      <div class="pd-gallery">
        <div class="pd-main-image">
          ${images[selectedImageIndex] ? `<img id="pdMainImg" src="${images[selectedImageIndex]}" alt="${StoreCommon.escapeHtml(product.name)}">` : `<div class="img-placeholder large">No Image</div>`}
        </div>
        <div class="pd-thumbs">
          ${images.map((img, i) => img ? `<img class="pd-thumb ${i === selectedImageIndex ? "active" : ""}" data-idx="${i}" src="${img}">` : "").join("")}
        </div>
      </div>

      <div class="pd-info">
        <h1>${StoreCommon.escapeHtml(product.name)}</h1>
        <div class="pd-price">
          <span class="price-now">${StoreCommon.formatPrice(product.price)}</span>
          ${hasDiscount ? `<span class="price-old">${StoreCommon.formatPrice(product.oldPrice)}</span>` : ""}
        </div>
        <p class="pd-desc">${StoreCommon.escapeHtml(product.description)}</p>

        <div class="pd-selector">
          <label>Size منتخب کریں:</label>
          <div class="option-row" id="sizeOptions">
            ${sizes.map(s => `<button class="option-btn" data-size="${StoreCommon.escapeHtml(s)}">${StoreCommon.escapeHtml(s)}</button>`).join("")}
          </div>
        </div>

        <div class="pd-selector">
          <label>Color منتخب کریں:</label>
          <div class="option-row" id="colorOptions">
            ${colors.map(c => `<button class="option-btn" data-color="${StoreCommon.escapeHtml(c)}">${StoreCommon.escapeHtml(c)}</button>`).join("")}
          </div>
        </div>

        <div id="stockMessage" class="stock-message"></div>

        ${product.sizeGuide ? `<details class="size-guide"><summary>Size Guide دیکھیں</summary><p>${StoreCommon.escapeHtml(product.sizeGuide)}</p></details>` : ""}

        <div class="pd-qty">
          <label>Quantity:</label>
          <div class="qty-control">
            <button id="qtyMinus">−</button>
            <input type="number" id="qtyInput" value="1" min="1">
            <button id="qtyPlus">+</button>
          </div>
        </div>

        <div class="pd-actions">
          <button class="btn-primary btn-large" id="btnAddToCart" disabled>Cart میں شامل کریں</button>
          <button class="btn-whatsapp btn-large" id="btnOrderWhatsApp" disabled>WhatsApp پر آرڈر کریں</button>
        </div>
        <div id="pdError" class="error-box"></div>
      </div>
    `;

    bindEvents();
    updateAvailability();
  }

  function bindEvents() {
    document.querySelectorAll(".pd-thumb").forEach(t => {
      t.addEventListener("click", () => {
        selectedImageIndex = Number(t.dataset.idx);
        render();
      });
    });

    document.querySelectorAll("#sizeOptions .option-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        if (btn.disabled) return;
        selectedSize = selectedSize === btn.dataset.size ? null : btn.dataset.size;
        updateAvailability();
      });
    });

    document.querySelectorAll("#colorOptions .option-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        if (btn.disabled) return;
        selectedColor = selectedColor === btn.dataset.color ? null : btn.dataset.color;
        updateAvailability();
      });
    });

    document.getElementById("qtyMinus").addEventListener("click", () => stepQty(-1));
    document.getElementById("qtyPlus").addEventListener("click", () => stepQty(1));

    document.getElementById("btnAddToCart").addEventListener("click", () => addToCart(false));
    document.getElementById("btnOrderWhatsApp").addEventListener("click", () => addToCart(true));
  }

  /** Size/Color بٹنوں کو موجودہ stock کے مطابق enable/disable/highlight کرتا ہے */
  function updateAvailability() {
    const sizeBtns = document.querySelectorAll("#sizeOptions .option-btn");
    const colorBtns = document.querySelectorAll("#colorOptions .option-btn");

    sizeBtns.forEach(btn => {
      const size = btn.dataset.size;
      const availableForThisSize = product.variants.some(v => v.size === size && v.stock > 0 && (!selectedColor || v.color === selectedColor));
      btn.classList.toggle("selected", selectedSize === size);
      btn.disabled = !availableForThisSize && selectedSize !== size;
      btn.classList.toggle("disabled", btn.disabled);
    });

    colorBtns.forEach(btn => {
      const color = btn.dataset.color;
      const availableForThisColor = product.variants.some(v => v.color === color && v.stock > 0 && (!selectedSize || v.size === selectedSize));
      btn.classList.toggle("selected", selectedColor === color);
      btn.disabled = !availableForThisColor && selectedColor !== color;
      btn.classList.toggle("disabled", btn.disabled);
    });

    const stockMsg = document.getElementById("stockMessage");
    const addBtn = document.getElementById("btnAddToCart");
    const waBtn = document.getElementById("btnOrderWhatsApp");
    const variant = getSelectedVariant();

    if (selectedSize && selectedColor && variant) {
      if (variant.stock > 0) {
        stockMsg.textContent = `دستیاب اسٹاک: ${variant.stock}`;
        stockMsg.className = "stock-message in-stock";
        addBtn.disabled = false;
        waBtn.disabled = false;
        document.getElementById("qtyInput").max = variant.stock;
      } else {
        stockMsg.textContent = "معذرت، یہ combination اسٹاک میں موجود نہیں۔";
        stockMsg.className = "stock-message out-of-stock";
        addBtn.disabled = true;
        waBtn.disabled = true;
      }
    } else {
      stockMsg.textContent = "براہ کرم Size اور Color منتخب کریں۔";
      stockMsg.className = "stock-message";
      addBtn.disabled = true;
      waBtn.disabled = true;
    }
  }

  function getSelectedVariant() {
    return product.variants.find(v => v.size === selectedSize && v.color === selectedColor) || null;
  }

  function stepQty(delta) {
    const input = document.getElementById("qtyInput");
    const variant = getSelectedVariant();
    const max = variant ? variant.stock : 99;
    let val = Number(input.value) + delta;
    val = Math.max(1, Math.min(val, max || 1));
    input.value = val;
  }

  function addToCart(goToWhatsApp) {
    const variant = getSelectedVariant();
    const errorBox = document.getElementById("pdError");
    if (!variant || variant.stock <= 0) {
      errorBox.textContent = "براہ کرم دستیاب Size/Color منتخب کریں۔";
      return;
    }
    const qty = Math.max(1, Math.min(Number(document.getElementById("qtyInput").value), variant.stock));

    CartManager.addToCart({
      productId: product.id,
      productName: product.name,
      image: product.images[0] || "",
      size: variant.size,
      color: variant.color,
      price: product.price,
      quantity: qty,
      maxStock: variant.stock
    });

    errorBox.textContent = "";

    if (goToWhatsApp) {
      window.location.href = "cart.html";
    } else {
      window.location.href = "cart.html";
    }
  }
})();
