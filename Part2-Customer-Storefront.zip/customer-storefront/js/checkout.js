/**
 * checkout.js
 * Part 2 — Customer Storefront
 *
 * صرف checkout.html پر چلتا ہے۔ Cash on Delivery بنیادی order method ہے۔
 * Order confirm ہونے پر ایک صحیح فارمیٹ میں WhatsApp message client کے
 * WhatsApp number پر بھیجنے کے لیے تیار کیا جاتا ہے۔
 */

document.addEventListener("DOMContentLoaded", () => {
  const items = CartManager.getCart();
  const container = document.getElementById("checkoutContainer");

  if (items.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>Checkout سے پہلے کارٹ میں کوئی پروڈکٹ شامل کریں۔</p>
        <a href="shop.html" class="btn-primary">شاپنگ شروع کریں</a>
      </div>
    `;
    return;
  }

  renderSummary(items);
  bindForm(items);
});

function renderSummary(items) {
  const summaryBox = document.getElementById("orderSummary");
  summaryBox.innerHTML = `
    <h3>آرڈر خلاصہ</h3>
    ${items.map(i => `
      <div class="summary-line">
        <span>${StoreCommon.escapeHtml(i.productName)} (${StoreCommon.escapeHtml(i.size)}/${StoreCommon.escapeHtml(i.color)}) × ${i.quantity}</span>
        <span>${StoreCommon.formatPrice(i.price * i.quantity)}</span>
      </div>
    `).join("")}
    <div class="summary-line summary-total">
      <span>کل رقم</span>
      <span>${StoreCommon.formatPrice(CartManager.getTotal())}</span>
    </div>
    <div class="cod-note">💵 ادائیگی کا طریقہ: Cash on Delivery (COD)</div>
  `;
}

function bindForm(items) {
  const form = document.getElementById("checkoutForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const customer = {
      name: form.custName.value.trim(),
      phone: form.custPhone.value.trim(),
      whatsapp: form.custWhatsapp.value.trim(),
      address: form.custAddress.value.trim(),
      city: form.custCity.value.trim(),
      notes: form.custNotes.value.trim()
    };

    const errors = validateCustomer(customer);
    const errorBox = document.getElementById("checkoutErrors");
    if (errors.length) {
      errorBox.innerHTML = `<ul>${errors.map(e => `<li>${StoreCommon.escapeHtml(e)}</li>`).join("")}</ul>`;
      return;
    }
    errorBox.innerHTML = "";

    const message = StoreCommon.buildOrderMessage({
      storeName: window.CLIENT_DATA.store.storeName,
      items,
      customer
    });

    const waLink = StoreCommon.buildWhatsAppLink(window.CLIENT_DATA.contact.whatsappNumber, message);

    // آرڈر بھیجنے کے بعد کارٹ خالی کر دیں
    CartManager.clearCart();
    window.open(waLink, "_blank");
    window.location.href = "index.html";
  });
}

function validateCustomer(c) {
  const errors = [];
  if (!c.name || c.name.length < 2) errors.push("براہ کرم اپنا نام درج کریں۔");
  if (!/^[0-9+\-\s()]{7,20}$/.test(c.phone)) errors.push("فون نمبر درست فارمیٹ میں درج کریں۔");
  if (!c.address || c.address.length < 5) errors.push("براہ کرم مکمل پتہ درج کریں۔");
  if (!c.city) errors.push("براہ کرم شہر درج کریں۔");
  return errors;
}
