const Validation = {
  isValidWhatsAppNumber(number) {
    if (!number) return false;
    return /^[1-9][0-9]{7,14}$/.test(String(number).trim());
  },
  isValidPhoneNumber(number) {
    if (!number) return false;
    return /^[0-9+\-\s()]{7,20}$/.test(String(number).trim());
  },
  isValidUrl(url) {
    if (!url) return true;
    try {
      const parsed = new URL(String(url).trim());
      return parsed.protocol === "http:" || parsed.protocol === "https:";
    } catch {
      return String(url).startsWith("data:image") || String(url).startsWith("./") || String(url).startsWith("/");
    }
  },
  isValidPrice(value) {
    const n = Number(value);
    return Number.isFinite(n) && n >= 0;
  },
  isValidStock(value) {
    const n = Number(value);
    return Number.isInteger(n) && n >= 0;
  },
  isNonEmptyText(value, minLength = 1) {
    return typeof value === "string" && value.trim().length >= minLength;
  },
  findDuplicateVariants(variants) {
    const seen = new Set();
    const duplicates = [];
    (variants || []).forEach((v, index) => {
      const size = String(v?.size || "").trim().toLowerCase();
      const color = String(v?.color || "").trim().toLowerCase();
      const key = `${size}__${color}`;
      if (seen.has(key)) duplicates.push(index); else seen.add(key);
    });
    return duplicates;
  },
  validateProduct(product) {
    const errors = [];
    if (!this.isNonEmptyText(product.name, 2)) errors.push("Product name must contain at least 2 characters.");
    if (!this.isValidPrice(product.price)) errors.push("Price must be a valid non-negative number.");
    if (product.oldPrice && !this.isValidPrice(product.oldPrice)) errors.push("Old Price must be a valid number.");
    if (Number(product.oldPrice) > 0 && Number(product.oldPrice) <= Number(product.price)) errors.push("Old Price must be greater than Price.");
    if (!Array.isArray(product.variants)) {
      errors.push("Variants data is invalid.");
    } else {
      product.variants.forEach((v, i) => {
        const hasSize = String(v.size || "").trim();
        const hasColor = String(v.color || "").trim();
        if (!hasSize && !hasColor) errors.push(`Variant #${i + 1}: enter at least a Size or Color.`);
        if (!this.isValidStock(v.stock)) errors.push(`Variant #${i + 1}: Stock must be a non-negative whole number.`);
      });
      if (this.findDuplicateVariants(product.variants).length) errors.push("The same Size + Color combination exists more than once.");
    }
    return { valid: errors.length === 0, errors };
  },
  validateStoreInfo(store, contact) {
    const errors = [];
    if (!this.isNonEmptyText(store.storeName, 2)) errors.push("Store Name must contain at least 2 characters.");
    if (!this.isValidWhatsAppNumber(contact.whatsappNumber)) errors.push("Enter a valid WhatsApp number, for example 923001234567.");
    if (contact.phoneNumber && !this.isValidPhoneNumber(contact.phoneNumber)) errors.push("Phone Number format is invalid.");
    if (!this.isValidUrl(contact.facebookUrl)) errors.push("Facebook URL is invalid.");
    if (!this.isValidUrl(contact.instagramUrl)) errors.push("Instagram URL is invalid.");
    return { valid: errors.length === 0, errors };
  }
};
window.Validation = Validation;
